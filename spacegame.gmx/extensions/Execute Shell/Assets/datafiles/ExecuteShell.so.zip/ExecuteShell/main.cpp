#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#if defined(_WIN32)
    #include <windows.h>
#endif

extern "C"
{
    double ExecuteShell(char *fname,double wait)
    {
        #if defined(_WIN32)
            PROCESS_INFORMATION ProcessInfo;

            STARTUPINFO StartupInfo;

            ZeroMemory(&StartupInfo,sizeof(StartupInfo));
            StartupInfo.cb = sizeof StartupInfo;

            bool ret = (CreateProcess(NULL,fname,
                NULL,NULL,FALSE,0,NULL,
                NULL,&StartupInfo,&ProcessInfo));

            if (ret)
            {
                if ((bool)wait == true)
                {
                    WaitForSingleObject(ProcessInfo.hProcess,INFINITE);
                }

                CloseHandle(ProcessInfo.hThread);
                CloseHandle(ProcessInfo.hProcess);
            }

            return ret;
        #else
            if (system(NULL))
            {
                int ret = -1;

                if ((bool)wait == true)
                {
                    ret = system(fname);
                }
                else
                {
                    if (fork() == 0)
                    {
                        ret = system(fname);
                        exit(0);
                    }
                }

                return ret;
            }
            else
            {
                return -1;
            }
        #endif
    }
}
